/*"Sys" section from openweather API JSON file
Is used as a component of Weather class*/
public class Sys {

    public long sunrise;
    public long sunset;
}

