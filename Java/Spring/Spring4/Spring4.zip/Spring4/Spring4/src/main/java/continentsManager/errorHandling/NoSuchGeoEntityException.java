package continentsManager.errorHandling;

public class NoSuchGeoEntityException extends Exception {

    public NoSuchGeoEntityException(String string) {
        super(string);
    }
}
