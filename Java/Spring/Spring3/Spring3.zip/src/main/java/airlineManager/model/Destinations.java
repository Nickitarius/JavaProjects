package airlineManager.model;

public enum Destinations {
    Vasiani,
    Krasnodar,
    Sochi,
    Miniralniye_Vodi,
    Novorossiysk,
    Krymsk,
    Beslan,
    Nalchik,
    Mozdok,
    Sukhumi,
    Gudauta,
    Batumi,
    Kobuleti
}
